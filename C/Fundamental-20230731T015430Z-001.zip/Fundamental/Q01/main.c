#include <stdio.h> 

int main () {

    printf("My name is Sanoj Aminda.\n");
    printf("My school is Ch/Senanayake Central College, Madampe.\n");
    return 0;
}