#include <stdio.h>

int main()
{
    int age;

    printf("HI, HOW OLD ARE YOU? ");
    scanf("%d", &age);

    printf("\n\n");

    printf("WELCOME %d\n", age);
    printf("LET'S BE FRIENDS!\n");

    return 0;
}

