#include <stdio.h>

int main()
{

	printf("%5d%5d%5d\n\n", 2, 4, 8);
	printf("%5d%5d%5d\n\n", 3, 9, 27);
	printf("%5d%5d%5d\n\n", 4, 16, 64);

	return 0;
}

