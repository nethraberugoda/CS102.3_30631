#include <stdio.h>
#include <stdlib.h>

int main () {

    // for (int i = 0; i <= 100; i++) {

    //     printf("%d\n", i);
    // }

    int i = 0;
    // while (i <= 100) {

    //     printf("%d\n", i);
    //     i++;
    // }

    do {
        printf("%d\n", i);
        i++;
    } while (i <= 100);

    return 0;
}